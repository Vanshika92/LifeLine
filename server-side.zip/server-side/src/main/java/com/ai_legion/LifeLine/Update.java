package com.ai_legion.LifeLine;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Document(collection="recipients")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Update {
    @Id
    private ObjectId _id;
    private String name;
    private String address;
    private String phone;
    private String email;
}
